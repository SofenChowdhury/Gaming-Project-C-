﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fool_Game
{
    public partial class Fool_Game : Form
    {
        public Fool_Game()
        {
            InitializeComponent();
        }

        private void Start_button_MouseEnter(object sender, EventArgs e)
        {
            Start_button.BackColor = Color.Green;
        }

        private void Start_button_Click(object sender, EventArgs e)
        {
            Start_Game s = new Start_Game();
            s.Visible = true;
            this.Visible = false;
        }

        private void Start_button_MouseLeave(object sender, EventArgs e)
        {
            Start_button.BackColor = Color.Silver;
        }

        private void Exit_button_MouseEnter(object sender, EventArgs e)
        {
            Exit_button.BackColor = Color.Red;
        }

        private void Exit_button_MouseLeave(object sender, EventArgs e)
        {
            Exit_button.BackColor = Color.Silver;
        }

        private void Exit_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
