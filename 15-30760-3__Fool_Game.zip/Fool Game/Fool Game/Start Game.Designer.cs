﻿namespace Fool_Game
{
    partial class Start_Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Yes_button = new System.Windows.Forms.Button();
            this.No_button = new System.Windows.Forms.Button();
            this.Back_button = new System.Windows.Forms.Button();
            this.Title_label = new System.Windows.Forms.Label();
            this.Start_timer = new System.Windows.Forms.Timer(this.components);
            this.Timer_label = new System.Windows.Forms.Label();
            this.Sec_label = new System.Windows.Forms.Label();
            this.Timer_textBox = new System.Windows.Forms.TextBox();
            this.UseTimer_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Yes_button
            // 
            this.Yes_button.BackColor = System.Drawing.Color.Red;
            this.Yes_button.Location = new System.Drawing.Point(439, 579);
            this.Yes_button.Name = "Yes_button";
            this.Yes_button.Size = new System.Drawing.Size(139, 115);
            this.Yes_button.TabIndex = 0;
            this.Yes_button.Text = "YES";
            this.Yes_button.UseVisualStyleBackColor = false;
            this.Yes_button.Click += new System.EventHandler(this.Yes_button_Click);
            // 
            // No_button
            // 
            this.No_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.No_button.Location = new System.Drawing.Point(439, 257);
            this.No_button.Name = "No_button";
            this.No_button.Size = new System.Drawing.Size(139, 115);
            this.No_button.TabIndex = 1;
            this.No_button.Text = "NO";
            this.No_button.UseVisualStyleBackColor = false;
            this.No_button.Click += new System.EventHandler(this.No_button_Click);
            this.No_button.MouseEnter += new System.EventHandler(this.No_button_MouseEnter);
            this.No_button.MouseMove += new System.Windows.Forms.MouseEventHandler(this.No_button_MouseMove);
            // 
            // Back_button
            // 
            this.Back_button.Location = new System.Drawing.Point(22, 579);
            this.Back_button.Name = "Back_button";
            this.Back_button.Size = new System.Drawing.Size(139, 115);
            this.Back_button.TabIndex = 2;
            this.Back_button.Text = "BACK";
            this.Back_button.UseVisualStyleBackColor = true;
            this.Back_button.Click += new System.EventHandler(this.Back_button_Click);
            // 
            // Title_label
            // 
            this.Title_label.AutoSize = true;
            this.Title_label.BackColor = System.Drawing.Color.Red;
            this.Title_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title_label.Location = new System.Drawing.Point(349, 8);
            this.Title_label.Name = "Title_label";
            this.Title_label.Size = new System.Drawing.Size(313, 39);
            this.Title_label.TabIndex = 3;
            this.Title_label.Text = "ARE YOU FOOL ?";
            // 
            // Start_timer
            // 
            this.Start_timer.Interval = 1000;
            this.Start_timer.Tick += new System.EventHandler(this.Start_timer_Tick);
            // 
            // Timer_label
            // 
            this.Timer_label.AutoSize = true;
            this.Timer_label.Location = new System.Drawing.Point(795, 15);
            this.Timer_label.Name = "Timer_label";
            this.Timer_label.Size = new System.Drawing.Size(78, 32);
            this.Timer_label.TabIndex = 6;
            this.Timer_label.Text = "Time";
            // 
            // Sec_label
            // 
            this.Sec_label.AutoSize = true;
            this.Sec_label.Location = new System.Drawing.Point(970, 19);
            this.Sec_label.Name = "Sec_label";
            this.Sec_label.Size = new System.Drawing.Size(64, 32);
            this.Sec_label.TabIndex = 7;
            this.Sec_label.Text = "Sec";
            // 
            // Timer_textBox
            // 
            this.Timer_textBox.Location = new System.Drawing.Point(879, 12);
            this.Timer_textBox.Name = "Timer_textBox";
            this.Timer_textBox.Size = new System.Drawing.Size(85, 38);
            this.Timer_textBox.TabIndex = 8;
            this.Timer_textBox.Text = " 0";
            // 
            // UseTimer_button
            // 
            this.UseTimer_button.Location = new System.Drawing.Point(895, 579);
            this.UseTimer_button.Name = "UseTimer_button";
            this.UseTimer_button.Size = new System.Drawing.Size(139, 115);
            this.UseTimer_button.TabIndex = 9;
            this.UseTimer_button.Text = "Use Timer";
            this.UseTimer_button.UseVisualStyleBackColor = true;
            this.UseTimer_button.Click += new System.EventHandler(this.UseTimer_button_Click);
            // 
            // Start_Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1058, 724);
            this.Controls.Add(this.UseTimer_button);
            this.Controls.Add(this.Timer_textBox);
            this.Controls.Add(this.Sec_label);
            this.Controls.Add(this.Timer_label);
            this.Controls.Add(this.Title_label);
            this.Controls.Add(this.Yes_button);
            this.Controls.Add(this.Back_button);
            this.Controls.Add(this.No_button);
            this.Name = "Start_Game";
            this.Text = "Start_Game";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Yes_button;
        private System.Windows.Forms.Button No_button;
        private System.Windows.Forms.Button Back_button;
        private System.Windows.Forms.Label Title_label;
        private System.Windows.Forms.Timer Start_timer;
        private System.Windows.Forms.Label Timer_label;
        private System.Windows.Forms.Label Sec_label;
        private System.Windows.Forms.TextBox Timer_textBox;
        private System.Windows.Forms.Button UseTimer_button;
    }
}