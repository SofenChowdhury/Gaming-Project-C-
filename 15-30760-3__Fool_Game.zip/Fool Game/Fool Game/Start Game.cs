﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fool_Game
{
    public partial class Start_Game : Form
    {
        public Start_Game()
        {
            InitializeComponent();
        }

        private void No_button_MouseEnter(object sender, EventArgs e)
        {
            Random r1 = new Random();
            int x, y;
            x = r1.Next(300);
            y = r1.Next(200);
            No_button.Location = new Point(x, y);
        }

        private void No_button_MouseMove(object sender, MouseEventArgs e)
        {
            Random r1 = new Random();
            int x, y;
            x = r1.Next(300);
            y = r1.Next(200);
            No_button.Location = new Point(x, y);
        }

        private void Back_button_Click(object sender, EventArgs e)
        {
            Fool_Game f = new Fool_Game();
            f.Visible = true;
            this.Visible = false;
        }

        private void No_button_Click(object sender, EventArgs e)
        {
            MessageBox.Show("No,I am not a Fool");
        }

        private void Yes_button_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Yes,I am a Fool");
        }

        int Duration = 101;
        private void Start_timer_Tick(object sender, EventArgs e)
        {  
            Duration--;
            Timer_textBox.Text = Duration.ToString();
            if (Duration == 0)
            {
                Start_timer.Stop();
                MessageBox.Show("Time Up!!!");
                Duration = 101;
            }
            
        }

        private void UseTimer_button_Click(object sender, EventArgs e)
        {
            Start_timer.Enabled = true;
            Start_timer.Start();
        }
    }
}
