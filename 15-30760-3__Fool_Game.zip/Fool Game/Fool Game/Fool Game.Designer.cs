﻿namespace Fool_Game
{
    partial class Fool_Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Exit_button = new System.Windows.Forms.Button();
            this.Start_button = new System.Windows.Forms.Button();
            this.Title_label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Exit_button
            // 
            this.Exit_button.BackColor = System.Drawing.Color.Silver;
            this.Exit_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit_button.Location = new System.Drawing.Point(298, 375);
            this.Exit_button.Name = "Exit_button";
            this.Exit_button.Size = new System.Drawing.Size(143, 115);
            this.Exit_button.TabIndex = 0;
            this.Exit_button.Text = "E&xit";
            this.Exit_button.UseVisualStyleBackColor = false;
            this.Exit_button.Click += new System.EventHandler(this.Exit_button_Click);
            this.Exit_button.MouseEnter += new System.EventHandler(this.Exit_button_MouseEnter);
            this.Exit_button.MouseLeave += new System.EventHandler(this.Exit_button_MouseLeave);
            // 
            // Start_button
            // 
            this.Start_button.BackColor = System.Drawing.Color.Silver;
            this.Start_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Start_button.Location = new System.Drawing.Point(588, 375);
            this.Start_button.Name = "Start_button";
            this.Start_button.Size = new System.Drawing.Size(143, 115);
            this.Start_button.TabIndex = 1;
            this.Start_button.Text = "Start";
            this.Start_button.UseVisualStyleBackColor = false;
            this.Start_button.Click += new System.EventHandler(this.Start_button_Click);
            this.Start_button.MouseEnter += new System.EventHandler(this.Start_button_MouseEnter);
            this.Start_button.MouseLeave += new System.EventHandler(this.Start_button_MouseLeave);
            // 
            // Title_label
            // 
            this.Title_label.AutoSize = true;
            this.Title_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title_label.Location = new System.Drawing.Point(285, 70);
            this.Title_label.Name = "Title_label";
            this.Title_label.Size = new System.Drawing.Size(446, 78);
            this.Title_label.TabIndex = 2;
            this.Title_label.Text = "FOOL GAME";
            // 
            // Fool_Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OliveDrab;
            this.ClientSize = new System.Drawing.Size(1087, 719);
            this.Controls.Add(this.Title_label);
            this.Controls.Add(this.Start_button);
            this.Controls.Add(this.Exit_button);
            this.Name = "Fool_Game";
            this.Text = "Fool Game";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Exit_button;
        private System.Windows.Forms.Button Start_button;
        private System.Windows.Forms.Label Title_label;
    }
}

