﻿using System;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Calculator : Form
    {
        private double accumulator = 0;
        private char lastOperation;

        public Calculator()
        {
            InitializeComponent();
        }

        private void Operator_Pressed(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            char operation = button.Text[0];
            if (operation == 'C')
            {
                accumulator = 0;
            }
            else
            {
                double currentValue = double.Parse(Display.Text);
                switch (lastOperation)
                {
                    case '+': accumulator += currentValue; break;
                    case '-': accumulator -= currentValue; break;
                    case '×': accumulator *= currentValue; break;
                    case '÷': accumulator /= currentValue; break;
                    default: accumulator = currentValue; break;
                }
            }

            lastOperation = operation;
            if (operation == '=')
                Display.Text = accumulator.ToString();
            else
                Display.Text = "0";
        }

        private void Number_Pressed(object sender, EventArgs e)
        {
            string number = (sender as Button).Text;
            if (Display.Text == "0")
                Display.Text = number;
            else
                Display.Text = Display.Text + number;
        }

    }
}
