﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Click_Counter
{
    public partial class Form1 : Form
    {
        int counter = 0,i=0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.Green;
            timer1.Start();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_MouseClick(object sender, MouseEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (button1.BackColor == Color.Green) { if (i < 100)counter++; button4.BackColor = Color.Green; button1.BackColor = Color.Red; }
                else { if (i < 100)counter--; }
               // if (counter == -10) { timer1.Enabled = false; }
                label1.Text = counter.ToString();
            
        }
        private void button2_Click(object sender, EventArgs e)
        {

            if (button2.BackColor == Color.Green) { if (i < 100)counter++; button2.BackColor = Color.Red; button5.BackColor = Color.Green; }
                else { if (i < 100)counter--; }
               // if (counter == -10) { timer1.Enabled = false; }
                label1.Text = counter.ToString();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (button3.BackColor == Color.Green) { if (i < 100)counter++; button3.BackColor = Color.Red; button6.BackColor = Color.Green; }
                else { if (i < 100)counter--; }
                //if (counter == -10) { timer1.Enabled = false; }
                label1.Text = counter.ToString();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.BackColor == Color.Green) { if (i < 100)counter++; button4.BackColor = Color.Red; button2.BackColor = Color.Green; }
                else { if (i < 100)counter--; }
                //if (counter == -10) { timer1.Enabled = false; }
                label1.Text = counter.ToString();
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
                if (button5.BackColor == Color.Green) { 
                    if(i < 100)counter++; button5.BackColor = Color.Red; button3.BackColor = Color.Green; }
                else { if (i < 100)counter--; }
               // if (counter == -10) { timer1.Enabled = false; }
                label1.Text = counter.ToString();
            
        }

        private void button6_Click(object sender, EventArgs e)
        {

            if (button6.BackColor == Color.Green) { if (i < 100)counter++; button6.BackColor = Color.Red; button2.BackColor = Color.Green; }
                else { if (i < 100)counter--; }
               // if (counter == -10) { timer1.Enabled = false; }
                label1.Text = counter.ToString();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button8_MouseEnter(object sender, EventArgs e)
        {
            button8.BackColor = Color.Red;
        }

        private void button7_MouseEnter(object sender, EventArgs e)
        {
            button7.BackColor = Color.Green;
        }

        private void button7_MouseLeave(object sender, EventArgs e)
        {
            button7.BackColor = Color.Gray;
        }

        private void button8_MouseLeave(object sender, EventArgs e)
        {
            button8.BackColor = Color.Gray;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            textBox1.Text = i.ToString();
            if (i == 100) { timer1.Stop(); MessageBox.Show("End Game"); }
        }
      
    }
}
